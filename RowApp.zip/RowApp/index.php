<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Bienvenido a RowApp</title>

<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen"> 
<link href="bootstrap/css/bootstrap-theme.min.css" rel="stylesheet" media="screen"> 

<link rel="stylesheet" href="bootstrap/style.css" type="text/css" />
</head>
<body>

<div class="container" style="text-align:center;">
<div class="page-header">
  <h1>Bienvenido a RowApp!!!</h1>
</div>
	
	<div class="row">
	<div class="col-md-6"><a href="usuarios/administrador/index.php" class="btn btn-primary">Entrar entrenador</a></div>
	<div class="col-md-6"><a href="usuarios/remeros/index.php" class="btn btn-danger">Entrar remero</a></div>
	
	
	</div>

	
	
</div>

<script src="bootstrap/js/jquery.js" type="text/javascript"></script>
<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>


</body>
</html>