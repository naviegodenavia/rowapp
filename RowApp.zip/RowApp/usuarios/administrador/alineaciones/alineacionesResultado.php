<?php
session_start();
include_once '../../../conexion/dbconnect.php';

if(!isset($_SESSION['userSession']))
{
	header("Location: index.php");
}

$query = $MySQLi_CON->query("SELECT * FROM users_admin WHERE user_id=".$_SESSION['userSession']);
$userRow=$query->fetch_array();
$MySQLi_CON->close();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>RowApp - <?php echo $userRow['user_name']; ?></title>

<link href="../../../bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen"> 
<link href="../../../bootstrap/css/bootstrap-theme.min.css" rel="stylesheet" media="screen"> 

<link rel="stylesheet" href="../../../bootstrap/style.css" type="text/css" />
</head>
<body>

<nav class="navbar navbar-default">
      <div class="container">
        <div class="navbar-header">
           <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand">RowApp</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li><a href="../index.php">Inicio</a></li>
            <li><a href="../upload_trainer.php">Subir entreno</a></li>
			 <li class="dropdown">
				<a href="#" data-toggle="dropdown" class="dropdown-toggle">Configuracion Remeros <b class="caret"></b></a>
				<ul class="dropdown-menu">
					<li><a href="../remeros/alta_remero.php">Insertar remeros</a></li>
					<li><a href="../remeros/mostrarListadoRemero.php">Listado remeros</a></li>
				</ul>
			</li>
			<li><a href="../remeros/historial_remero.php">Regatas</a></li>
			<li><a href="../entrenos/ver_entreno.php">Entrenamientos</a></li>
			<li class="active"><a href="alineaciones.php">Alineaciones</a></li>
          </ul>
          <ul class="nav navbar-nav navbar-right">
            <li><a href="../usuario_perfil.php"><span class="glyphicon glyphicon-user"></span>&nbsp; <?php echo $userRow['user_name']; ?></a></li>
            <li><a href="../logout.php?logout"><span class="glyphicon glyphicon-log-out"></span>&nbsp; Logout</a></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>
	
<form name="MyForm" method="post">	
<!-- PROA -->
<div class="container">
<div class="row">
	<div class="col-md-12" style="padding-top:20px;text-align:center;">
		<div class="proa">
		<input type="text" class="form-control altura controlador" name="nombreproa" value="<?php echo $_POST['nombreproa']?>" maxlength="15" placeholder="Nombre Proa">
			 <div class="form-group">
			  <div class="col-sm-4"></div>
			  <div class="col-sm-2"><input type="text" name="pesoproa" value="<?php echo $_POST['pesoproa']?>" class="form-control altura" maxlength="3" placeholder="Peso XX"></div>
			  <div class="col-sm-2"><input type="text" name="potenciaproa" value="<?php echo $_POST['potenciaproa']?>" class="form-control altura" maxlength="3" placeholder="Pot. XXX"></div>
			</div>
		</div>
	</div>
</div>
<!-- 6 -->
<div class="row separacion">
	<div class="col-md-6">
		<div class="babor">
			<div class="divNombre controlador">
				<input type="text" class="form-control altura" name="b6nombre" value="<?php echo $_POST['b6nombre']?>" maxlength="15" placeholder="B6 Nombre"/>
			</div>
		<div class="form-group">
		  <div class="col-sm-2"></div>
		  <div class="col-sm-2"><input type="text" class="form-control altura" name="b6peso" value="<?php echo $_POST['b6peso']?>" maxlength="3" placeholder="Peso XX"></div>
		  <div class="col-sm-3"><input type="text" class="form-control altura" name="b6potencia" value="<?php echo $_POST['b6potencia']?>" maxlength="3" placeholder="Pot. XXX"></div>
		</div>
		</div>
	</div>
	<div class="col-md-6">
		<div class="estribor">
		<input type="text" class="form-control altura controlador" name="e6nombre" value="<?php echo $_POST['e6nombre']?>" maxlength="15" placeholder="E6 Nombre"/>
		<div class="form-group">
		  <div class="col-sm-2"></div>
		  <div class="col-sm-2"><input type="text" class="form-control altura" name="e6peso" value="<?php echo $_POST['e6peso']?>" maxlength="3" placeholder="Peso XX"></div>
		  <div class="col-sm-3"><input type="text" class="form-control altura" name="e6potencia" value="<?php echo $_POST['e6potencia']?>" maxlength="3" placeholder="Pot. XXX"></div>
		</div>
		</div>
	</div>
</div>

<!-- 5 -->
<div class="row separacion">
	<div class="col-md-6">
		<div class="babor">
			<div class="divNombre controlador">
				<input type="text" class="form-control altura" name="b5nombre" value="<?php echo $_POST['b5nombre']?>" maxlength="15" placeholder="B5 Nombre"/>
			</div>
		<div class="form-group">
		  <div class="col-sm-2"></div>
		  <div class="col-sm-2"><input type="text" class="form-control altura" value="<?php echo $_POST['b5peso']?>" name="b5peso" maxlength="3" placeholder="Peso XX"></div>
		  <div class="col-sm-3"><input type="text" class="form-control altura" value="<?php echo $_POST['b5potencia']?>" name="b5potencia" maxlength="3" placeholder="Pot. XXX"></div>
		</div>
		</div>
	</div>
	<div class="col-md-6">
		<div class="estribor">
		<input type="text" class="form-control altura controlador" name="e5nombre" value="<?php echo $_POST['e5nombre']?>" maxlength="15" placeholder="E5 Nombre"/>
		<div class="form-group">
		  <div class="col-sm-2"></div>
		  <div class="col-sm-2"><input type="text" class="form-control altura" name="e5peso" value="<?php echo $_POST['e5peso']?>" maxlength="3" placeholder="Peso XX"></div>
		  <div class="col-sm-3"><input type="text" class="form-control altura" name="e5potencia" value="<?php echo $_POST['e5potencia']?>" maxlength="3" placeholder="Pot. XXX"></div>
		</div>
		</div>
	</div>
</div>

<!-- 4 -->
<div class="row separacion">
	<div class="col-md-6">
		<div class="babor">
			<div class="divNombre controlador">
				<input type="text" class="form-control altura" name="b4nombre" value="<?php echo $_POST['b4nombre']?>" maxlength="15" placeholder="B4 Nombre"/>
			</div>
		<div class="form-group">
		  <div class="col-sm-2"></div>
		  <div class="col-sm-2"><input type="text" class="form-control altura" name="b4peso" value="<?php echo $_POST['b4peso']?>" maxlength="3" placeholder="Peso XX"></div>
		  <div class="col-sm-3"><input type="text" class="form-control altura" name="b4potencia" value="<?php echo $_POST['b4potencia']?>" maxlength="3" placeholder="Pot. XXX"></div>
		</div>
		</div>
	</div>
	<div class="col-md-6">
		<div class="estribor">
		<input type="text" class="form-control altura controlador" name="e4nombre" value="<?php echo $_POST['e4nombre']?>" maxlength="15" placeholder="E5 Nombre"/>
		<div class="form-group">
		  <div class="col-sm-2"></div>
		  <div class="col-sm-2"><input type="text" class="form-control altura" name="e4peso" value="<?php echo $_POST['e4peso']?>" maxlength="3" placeholder="Peso XX"></div>
		  <div class="col-sm-3"><input type="text" class="form-control altura" name="e4potencia" maxlength="3" value="<?php echo $_POST['e4potencia']?>" placeholder="Pot. XXX"></div>
		</div>
		</div>
	</div>
</div>

<!-- 3 -->
<div class="row separacion">
	<div class="col-md-6">
		<div class="babor">
			<div class="divNombre controlador">
				<input type="text" class="form-control altura" name="b3nombre" value="<?php echo $_POST['b3nombre']?>" maxlength="15" placeholder="B3 Nombre"/>
			</div>
		<div class="form-group">
		  <div class="col-sm-2"></div>
		  <div class="col-sm-2"><input type="text" class="form-control altura" name="b3peso" value="<?php echo $_POST['b3peso']?>" maxlength="3" placeholder="Peso XX"></div>
		  <div class="col-sm-3"><input type="text" class="form-control altura" name="b3potencia" maxlength="3" value="<?php echo $_POST['b3potencia']?>" placeholder="Pot. XXX"></div>
		</div>
		</div>
	</div>
	<div class="col-md-6">
		<div class="estribor">
		<input type="text" class="form-control altura controlador" name="e3nombre" value="<?php echo $_POST['e3nombre']?>" maxlength="15" value="<?php echo $_POST['enombre']?>" placeholder="E3 Nombre"/>
		<div class="form-group">
		  <div class="col-sm-2"></div>
		  <div class="col-sm-2"><input type="text" class="form-control altura" name="e3peso" value="<?php echo $_POST['e3peso']?>" maxlength="3" placeholder="Peso XX"></div>
		  <div class="col-sm-3"><input type="text" class="form-control altura" name="e3potencia" maxlength="3" value="<?php echo $_POST['e3potencia']?>" placeholder="Pot. XXX"></div>
		</div>
		</div>
	</div>
</div>

<!-- 2 -->
<div class="row separacion">
	<div class="col-md-6">
		<div class="babor">
			<div class="divNombre controlador">
				<input type="text" class="form-control altura" name="b2nombre" value="<?php echo $_POST['b2nombre']?>" maxlength="15" placeholder="B2 Nombre"/>
			</div>
		<div class="form-group">
		  <div class="col-sm-2"></div>
		  <div class="col-sm-2"><input type="text" class="form-control altura" value="<?php echo $_POST['b2peso']?>" name="b2peso" maxlength="3" placeholder="Peso XX"></div>
		  <div class="col-sm-3"><input type="text" class="form-control altura" name="b2potencia" value="<?php echo $_POST['b2potencia']?>" maxlength="3" placeholder="Pot. XXX"></div>
		</div>
		</div>
	</div>
	<div class="col-md-6">
		<div class="estribor">
		<input type="text" class="form-control altura controlador" name="e2nombre" value="<?php echo $_POST['e2nombre']?>" maxlength="15" placeholder="E2 Nombre"/>
		<div class="form-group">
		  <div class="col-sm-2"></div>
		  <div class="col-sm-2"><input type="text" class="form-control altura" name="e2peso" value="<?php echo $_POST['e2peso']?>" maxlength="3" placeholder="Peso XX"></div>
		  <div class="col-sm-3"><input type="text" class="form-control altura" name="e2potencia" maxlength="3" value="<?php echo $_POST['e2potencia']?>" placeholder="Pot. XXX"></div>
		</div>
		</div>
	</div>
</div>

<!-- MARCAS 1-->
<div class="row separacion">
	<div class="col-md-6">
		<div class="babor">
			<div class="divNombre controlador">
				<input type="text" class="form-control altura" name="b1nombre" value="<?php echo $_POST['b1nombre']?>" maxlength="15" placeholder="B1 Nombre"/>
			</div>
		<div class="form-group">
		  <div class="col-sm-2"></div>
		  <div class="col-sm-2"><input type="text" class="form-control altura" name="b1peso" value="<?php echo $_POST['b1peso']?>" maxlength="3" placeholder="Peso XX"></div>
		  <div class="col-sm-3"><input type="text" class="form-control altura" name="b1potencia" maxlength="3" value="<?php echo $_POST['b1potencia']?>" placeholder="Pot. XXX"></div>
		</div>
		</div>
	</div>
	<div class="col-md-6">
		<div class="estribor">
		<input type="text" class="form-control altura controlador" name="e1nombre" value="<?php echo $_POST['e1nombre']?>" maxlength="15" placeholder="E1 Nombre"/>
		<div class="form-group">
		  <div class="col-sm-2"></div>
		  <div class="col-sm-2"><input type="text" class="form-control altura" name="e1peso" value="<?php echo $_POST['e1peso']?>" maxlength="3" placeholder="Peso XX"></div>
		  <div class="col-sm-3"><input type="text" class="form-control altura" name="e1potencia" maxlength="3" value="<?php echo $_POST['e1potencia']?>" placeholder="Pot. XXX"></div>
		</div>
		</div>
	</div>
</div>
<!-- PATRON -->
<div class="row separacion">
	<div class="col-md-12" style="text-align:center;">
		<div class="proa">
		<input type="text" class="form-control altura controlador" name="nombrepatron" value="<?php echo $_POST['nombrepatron']?>" maxlength="15" placeholder="Nombre Patron">
			 <div class="form-group">
			  <div class="col-sm-4"></div>
			  <div class="col-sm-2"><input type="text" name="pesopatron" maxlength="3" value="<?php echo $_POST['pesopatron']?>" class="form-control altura" placeholder="Peso XX"></div>
			  <div class="col-sm-2"><input disabled type="text" maxlength="3" name="potenciapatron" class="form-control altura" placeholder="Pot. XXX"></div>
			</div>
		</div>
	</div>
</div>
</div>
<div class="container text-center separacion">
	<input type="submit" class="btn btn-default" name="enviar" value="Calcular" />
	<input type="button" class="btn btn-default" name="imprimir" value="Imprimir" onclick="window.print();">
	  <a href="alineaciones.php" class="btn btn-default">Borrar</a>
</div>

</form>

<div class="container separacion paddingBottom">
<div class="col-md-6">
<p class="text-center">PESO</p>
<?php

if (isset($_POST['enviar'])){

$pesoproa = $_POST["pesoproa"];
$b6peso = $_POST["b6peso"];
$b5peso = $_POST["b5peso"];
$b4peso = $_POST["b4peso"];
$b3peso = $_POST["b3peso"];
$b2peso = $_POST["b2peso"];
$b1peso = $_POST["b1peso"];

$e6peso = $_POST["e6peso"];
$e5peso = $_POST["e5peso"];
$e4peso = $_POST["e4peso"];
$e3peso = $_POST["e3peso"];
$e2peso = $_POST["e2peso"];
$e1peso = $_POST["e1peso"];
$pesopatron = $_POST["pesopatron"];

$pesoEstribor = ($pesoproa/2) + $e6peso + $e5peso + $e4peso + $e3peso + $e2peso + $e1peso + ($pesopatron/2);
$pesoBabor = ($pesoproa/2) + $b6peso + $b5peso + $b4peso + $b3peso + $b2peso + $b1peso + ($pesopatron/2);
$pesoTotal = $pesoproa + $e6peso + $e5peso + $e4peso + $e3peso + $e2peso + $e1peso + $b6peso + $b5peso + $b4peso + $b3peso + $b2peso + $b1peso + $pesopatron;
$diferenciaPeso = $pesoEstribor - $pesoBabor;


?>
<div class="col-md-6">
<?php echo "Peso Babor: "; ?>
<?php echo '<input type="text" disabled value="' . $pesoBabor . ' kg">'."<br>";?>
<?php echo "Peso Estribor:"; ?>
<?php echo '<input type="text" disabled value="' . $pesoEstribor . ' kg">'."<br>"; ?>
</div>

<div class="col-md-6">
<?php echo "Peso Total: "; ?>
<?php echo '<input type="text" disabled value="' . $pesoTotal . ' kg">'."<br>"; ?>
<?php echo "Diferencia bandas: "; ?>
<?php echo '<input type="text" disabled value="' . $diferenciaPeso . ' kg">'; ?>
</div>



<?php
}
?>


</div>

<div class="col-md-6">
<p class="text-center">POTENCIA</p>
<?php

if (isset($_POST['enviar'])){

$potenciaproa = $_POST["potenciaproa"];
$b6potencia = $_POST["b6potencia"];
$b5potencia = $_POST["b5potencia"];
$b4potencia = $_POST["b4potencia"];
$b3potencia = $_POST["b3potencia"];
$b2potencia = $_POST["b2potencia"];
$b1potencia = $_POST["b1potencia"];

$e6potencia = $_POST["e6potencia"];
$e5potencia = $_POST["e5potencia"];
$e4potencia = $_POST["e4potencia"];
$e3potencia = $_POST["e3potencia"];
$e2potencia = $_POST["e2potencia"];
$e1potencia = $_POST["e1potencia"];

$potenciaEstribor = ($potenciaproa/2) + $e6potencia + $e5potencia + $e4potencia + $e3potencia + $e2potencia + $e1potencia;
$potenciaBabor = ($potenciaproa/2) + $b6potencia + $b5potencia + $b4potencia + $b3potencia + $b2potencia + $b1potencia;
$potenciaTotal = $potenciaproa + $e6potencia + $e5potencia + $e4potencia + $e3potencia + $e2potencia + $e1potencia + $b6potencia + $b5potencia + $b4potencia + $b3potencia + $b2potencia + $b1potencia;
$diferenciaPotencia = $potenciaEstribor - $potenciaBabor;


?>
<div class="col-md-6">
<?php echo "Potencia Babor: "; ?>
<?php echo '<input type="text" disabled value="' . $potenciaBabor . ' wats">'."<br>";?>
<?php echo "Potencia Estribor:"; ?>
<?php echo '<input type="text" disabled value="' . $potenciaEstribor . ' wats">'."<br>"; ?>
</div>

<div class="col-md-6">
<?php echo "Potencia Total: "; ?>
<?php echo '<input type="text" disabled value="' . $potenciaTotal . ' wats">'."<br>"; ?>
<?php echo "Diferencia bandas: "; ?>
<?php echo '<input type="text" disabled value="' . $diferenciaPotencia . ' wats">'; ?>
</div>

<?php
}
?>


</div>

<script src="../../../bootstrap/js/jquery.js" type="text/javascript"></script>
<script type="text/javascript" src="../../../bootstrap/js/bootstrap.min.js"></script>

</body>
</html>