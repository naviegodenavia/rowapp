<?php
session_start();
include_once '../../../conexion/dbconnect.php';

if(!isset($_SESSION['userSession']))
{
	header("Location: index.php");
}

$query = $MySQLi_CON->query("SELECT * FROM users_admin WHERE user_id=".$_SESSION['userSession']);
$userRow=$query->fetch_array();


if(isset($_POST['btn-signup']))
{
	$uname = $MySQLi_CON->real_escape_string(trim($_POST['user_name']));
	$email = $MySQLi_CON->real_escape_string(trim($_POST['user_email']));
	$upass = $MySQLi_CON->real_escape_string(trim($_POST['password']));
	
	$new_password = password_hash($upass, PASSWORD_DEFAULT);
	
	$check_email = $MySQLi_CON->query("SELECT user_email FROM users_remero WHERE user_email='$email'");
	$count=$check_email->num_rows;
	
	if($count==0){
		
		
		$query = "INSERT INTO users_remero(user_name,user_email,user_pass) VALUES('$uname','$email','$new_password')";

		
		if($MySQLi_CON->query($query))
		{
			$msg = "<div class='alert alert-success'>
						<span class='glyphicon glyphicon-info-sign'></span> &nbsp; Registro completado !
					</div>";
		}
		else
		{
			$msg = "<div class='alert alert-danger'>
						<span class='glyphicon glyphicon-info-sign'></span> &nbsp; Error mientras se registraba !
					</div>";
		}
	}
	else{
		
		
		$msg = "<div class='alert alert-danger'>
					<span class='glyphicon glyphicon-info-sign'></span> &nbsp; El email ya existe !
				</div>";
			
	}
	
	$MySQLi_CON->close();
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>RowApp - <?php echo $userRow['user_name']; ?></title>

<link href="../../../bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen"> 
<link href="../../../bootstrap/css/bootstrap-theme.min.css" rel="stylesheet" media="screen"> 

<link rel="stylesheet" href="../../../bootstrap/style.css" type="text/css" />
</head>
<body>

<nav class="navbar navbar-default">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand">RowApp</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li><a href="../index.php">Inicio</a></li>
            <li><a href="../upload_trainer.php">Subir entreno</a></li>
			<li class="active dropdown">
				<a href="#" data-toggle="dropdown" class="dropdown-toggle">Configuracion Remeros <b class="caret"></b></a>
				<ul class="dropdown-menu">
					<li><a href="alta_remero.php">Insertar remeros</a></li>
					<li><a href="mostrarListadoRemero.php">Listado remeros</a></li>
				</ul>
			</li>
			<li><a href="historial_remero.php">Regatas</a></li>
			<li><a href="../entrenos/ver_entreno.php">Entrenamientos</a></li>
			<li><a href="../alineaciones/alineaciones.php">Alineaciones</a></li>
          </ul>
          <ul class="nav navbar-nav navbar-right">
            <li><a href="../usuario_perfil.php"><span class="glyphicon glyphicon-user"></span>&nbsp; <?php echo $userRow['user_name']; ?></a></li>
            <li><a href="../logout.php?logout"><span class="glyphicon glyphicon-log-out"></span>&nbsp; Logout</a></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>

	<div class="signin-form">
<div class="container" style="text-align:center;">

	       <form class="form-signin" method="post" id="register-form">
      
        <h2 class="form-signin-heading">Dar de alta remeros</h2><hr />
        
        <?php
		if(isset($msg)){
			echo $msg;
		}
		else{
			?>
            <div class='alert alert-info'>
				<span class='glyphicon glyphicon-asterisk'></span> &nbsp; Todos los campos son obligatorios !
			</div>
            <?php
		}
		?>
        <div class="form-group">
        <input type="text" class="form-control" placeholder="Nombre *" name="user_name" required  />
        </div>
        
        <div class="form-group">
        <input type="email" class="form-control" placeholder="Email *" name="user_email" required  />
        <span id="check-e"></span>
        </div>
        
        <div class="form-group">
        <input type="password" class="form-control" placeholder="Contraseña *" name="password" required  />
        </div>
        
     	<hr />
        
        <div class="form-group">
            <button type="submit" class="btn btn-default" name="btn-signup">
    		<span class="glyphicon glyphicon-log-in"></span> &nbsp; Crear Cuenta
			</button> 
        </div> 
      
      </form>
	
</div>
</div>

<script src="../../../bootstrap/js/jquery.js" type="text/javascript"></script>
<script type="text/javascript" src="../../../bootstrap/js/bootstrap.min.js"></script>


</body>
</html>