<?php
session_start();
include_once '../../conexion/dbconnect.php';

if(!isset($_SESSION['userSession']))
{
	header("Location: index.php");
}

$query = $MySQLi_CON->query("SELECT * FROM users_admin WHERE user_id=".$_SESSION['userSession']);
$userRow=$query->fetch_array();
$MySQLi_CON->close();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>RowApp - <?php echo $userRow['user_name']; ?></title>

<link href="../../bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen"> 
<link href="../../bootstrap/css/bootstrap-theme.min.css" rel="stylesheet" media="screen"> 

<link rel="stylesheet" href="../../bootstrap/style.css" type="text/css" />

</head>
<body>

<nav class="navbar navbar-default">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
            <a class="navbar-brand">RowApp</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li><a href="index.php">Inicio</a></li>
            <li class="active"><a href="upload_trainer.php">Subir entreno</a></li>
			 <li class="dropdown">
				<a href="#" data-toggle="dropdown" class="dropdown-toggle">Configuracion Remeros <b class="caret"></b></a>
				<ul class="dropdown-menu">
					<li><a href="remeros/alta_remero.php">Insertar remeros</a></li>
					<li><a href="remeros/mostrarListadoRemero.php">Listado remeros</a></li>
				</ul>
			</li>
			<li><a href="remeros/historial_remero.php">Regatas</a></li>
			<li><a href="entrenos/ver_entreno.php">Entrenamientos</a></li>
			<li><a href="alineaciones/alineaciones.php">Alineaciones</a></li>
          </ul>
          <ul class="nav navbar-nav navbar-right">
            <li><a href="usuario_perfil.php"><span class="glyphicon glyphicon-user"></span>&nbsp; <?php echo $userRow['user_name']; ?></a></li>
            <li><a href="logout.php?logout"><span class="glyphicon glyphicon-log-out"></span>&nbsp; Logout</a></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>

<div class="container" style="text-align:center;">
<div class="page-header">
  <h1>Entrenamientos</h1>
</div>	
	<?php
		if(isset($_GET["message"])){
		?>
		<div class="alert alert-danger">
		  <strong>Entrenamiento borrado</strong>
		</div>
		<?php
		}
	?>

<form class="formularioSubida" action="" method="post" enctype="multipart/form-data" name="form1">
<input type="file" name="resume" id="resume">
<input type="submit" name="SubmitBtn" id="SubmitBtn" value="Upload Resume">
</form>

<?php
if(isset($_POST["SubmitBtn"])){

$fileName=$_FILES["resume"]["name"];
$fileSize=$_FILES["resume"]["size"]/1024;
$fileType=$_FILES["resume"]["type"];
$fileTmpName=$_FILES["resume"]["tmp_name"];  

if($fileType=="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"){
if($fileSize<=200){

//$random=date("Y-m-d");$random.
$newFileName=$fileName;

$uploadPath="ficheros/".$newFileName;

if(move_uploaded_file($fileTmpName,$uploadPath)){
  echo "Se ha subido el fichero<BR>"; 
}
}
else{
  echo "El tamaño máximo es de 200 kb";
}
}
else{
  echo "Solo puedes subir documentos office";
}  

}
?> 

	<?php
		$path="ficheros/"; 
		$directorio=dir($path);
		while ($archivo = $directorio->read())
			{
			if($archivo === '.' || $archivo === '..') {continue;}
			$descarga = $path."".$archivo;
			echo "<a href=".$descarga.">".$archivo."</a>"."<a title='Borrar entrenamiento' href='delete_trainer.php?entreno=".$descarga."'><span class='glyphicon glyphicon-remove'></span></a>"."<br>";
			}	
		$directorio->close();
	?>
</div>


<script src="../../bootstrap/js/jquery.js" type="text/javascript"></script>
<script type="text/javascript" src="../../bootstrap/js/bootstrap.min.js"></script>
</body>
</html>