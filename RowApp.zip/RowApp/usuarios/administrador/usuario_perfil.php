<?php
session_start();
include_once '../../conexion/dbconnect.php';

if(!isset($_SESSION['userSession']))
{
	header("Location: index.php");
}

$query = $MySQLi_CON->query("SELECT * FROM users_admin WHERE user_id=".$_SESSION['userSession']);
$userRow=$query->fetch_array();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>RowApp - <?php echo $userRow['user_name']; ?></title>

<link href="../../bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen"> 
<link href="../../bootstrap/css/bootstrap-theme.min.css" rel="stylesheet" media="screen"> 

<link rel="stylesheet" href="../../bootstrap/style.css" type="text/css" />
</head>
<body>

<nav class="navbar navbar-default">
      <div class="container">
        <div class="navbar-header">
           <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand">RowApp</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li><a href="index.php">Inicio</a></li>
            <li><a href="upload_trainer.php">Subir entreno</a></li>
			 <li class="dropdown">
				<a href="#" data-toggle="dropdown" class="dropdown-toggle">Configuracion Remeros <b class="caret"></b></a>
				<ul class="dropdown-menu">
					<li><a href="remeros/alta_remero.php">Insertar remeros</a></li>
					<li><a href="remeros/mostrarListadoRemero.php">Listado remeros</a></li>
				</ul>
			</li>
			<li><a href="remeros/historial_remero.php">Regatas</a></li>
			<li><a href="entrenos/ver_entreno.php">Entrenamientos</a></li>
			<li><a href="alineaciones/alineaciones.php">Alineaciones</a></li>
          </ul>
          <ul class="nav navbar-nav navbar-right">
            <li class="active"><a href="usuario_perfil.php"><span class="glyphicon glyphicon-user"></span>&nbsp; <?php echo $userRow['user_name']; ?></a></li>
            <li><a href="logout.php?logout"><span class="glyphicon glyphicon-log-out"></span>&nbsp; Logout</a></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>

<div class="container" style="text-align:center;">
<?php
if(isset($_POST['perfilUser']))
{

$email = $_POST['user_email'];
$upass = $MySQLi_CON->real_escape_string(trim($_POST['password']));
$new_password = password_hash($upass, PASSWORD_DEFAULT);


#Insertar datos
$consulta = "UPDATE users_admin SET user_email='$email',user_pass='$new_password' WHERE user_id=".$_SESSION['userSession'];
$resultado = $MySQLi_CON -> query($consulta)|| die("Ha ocurrido un error al guardar los datos");

}

#Extraer todas las filas
$consulta = "SELECT * FROM users_admin WHERE user_id=".$_SESSION['userSession'];
$resultado = $MySQLi_CON -> query($consulta);
?>

<?php
while($fila = $resultado -> fetch_array())
{
?>

    <form class="form-signin" method="post" id="register-form">
      
        <h2 class="form-signin-heading">Cambiar datos</h2><hr />
        
        <?php
		if(isset($msg)){
			echo "aaaa";
		}
		else{
			?>
            <div class='alert alert-info'>
				<span class='glyphicon glyphicon-asterisk'></span> &nbsp; Puedes cambiar tus datos !
			</div>
            <?php
		}
		?>
          
        <div class="form-group">
        <input type="text" class="form-control" value="<?php echo $fila["user_name"]; ?>" placeholder="Username" name="user_name" disabled />
        </div>
        
        <div class="form-group">
        <input type="email" class="form-control" value="<?php echo $fila["user_email"]; ?>" placeholder="Email address" name="user_email"  />
        <span id="check-e"></span>
        </div>
        
        <div class="form-group">
        <input type="password" class="form-control" placeholder="Password" name="password" required  />
        </div>
        
     	<hr />
        
        <div class="form-group">
            <button type="submit" class="btn btn-default" name="perfilUser">
    		<span class="glyphicon glyphicon-log-in"></span> &nbsp; Actualizar
			</button> 
         <a href="register.php" class="btn btn-default" style="float:right;">Insertar Admin</a>
        </div> 
      
      </form>

<?php
}
mysqli_close($MySQLi_CON);
?>



</div>

<script src="../../bootstrap/js/jquery.js" type="text/javascript"></script>
<script type="text/javascript" src="../../bootstrap/js/bootstrap.min.js"></script>


</body>
</html>