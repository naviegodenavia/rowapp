<?php
session_start();

if(!isset($_SESSION['userSessiones']))
{
	header("Location: index.php");
}
else if(isset($_SESSION['userSessiones'])!="")
{
	header("Location: home.php");
}

if(isset($_GET['logout']))
{
	session_destroy();
	unset($_SESSION['userSessiones']);
	header("Location: index.php");
}
?>