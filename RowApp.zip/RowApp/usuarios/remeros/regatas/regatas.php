<?php
session_start();
include_once '../../../conexion/dbconnect.php';

if(!isset($_SESSION['userSessiones']))
{
	header("Location: index.php");
}

$query = $MySQLi_CON->query("SELECT * FROM users_remero WHERE user_id=".$_SESSION['userSessiones']);
$userRow=$query->fetch_array();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>RowApp - <?php echo $userRow['user_name']; ?></title>

<link href="../../../bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen"> 
<link href="../../../bootstrap/css/bootstrap-theme.min.css" rel="stylesheet" media="screen"> 

<link rel="stylesheet" href="../../../bootstrap/style.css" type="text/css" />
</head>
<body>

<nav class="navbar navbar-default">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand">RowApp</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li><a href="../index.php">Inicio</a></li>
			<li class="active dropdown">
				<a href="#" data-toggle="dropdown" class="dropdown-toggle">Remeros <b class="caret"></b></a>
				<ul class="dropdown-menu">
					<li><a href="regatas.php">Ver resultados regatas</a></li>
					<li><a href="insertar_regata.php">Insertar Regata</a></li>
				</ul>
			</li>
			<li class="dropdown">
				<a href="#" data-toggle="dropdown" class="dropdown-toggle">Entrenamientos <b class="caret"></b></a>
				<ul class="dropdown-menu">
					<li><a href="../entrenamientos/ver_entreno.php">Ver entrenamiento</a></li>
					<li><a href="../entrenamientos/insertar_entreno.php">Insertar entrenamiento</a></li>
				</ul>
			</li>
          </ul>
          <ul class="nav navbar-nav navbar-right">
            <li><a href="../usuario_perfil.php"><span class="glyphicon glyphicon-user"></span>&nbsp; <?php echo $userRow['user_name']; ?></a></li>
            <li><a href="../logout.php?logout"><span class="glyphicon glyphicon-log-out"></span>&nbsp; Logout</a></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>

<div class="container" style="text-align:center;">
<?php
if(isset($_GET["message"]))
{
?>
<div class="alert alert-success">
  <strong>Regata actualizada correctamente! </strong>
</div>
<?php
}
?>
<div class="page-header">
  <h1>Regatas</h1>
</div>
	
	<?php

#Extraer todas las filas
$consulta = "SELECT * FROM historialremero WHERE id_remero=".$_SESSION['userSessiones'];
$resultado = $MySQLi_CON -> query($consulta);
$row_cnt = $resultado->num_rows;

if($row_cnt <=0){
echo '<div class="alert alert-warning" role="alert">No existen regatas. Por favor, inserta resultados</div>';
}else{
?>
<table class="table table-bordered table-hover">
    <thead>
        <tr>
            <th>Puesto</th>
            <th>Modalidad</th>
            <th>Tiempo</th>
			<th>Campo de Regatas</th>	
            <th>Fecha</th>	
        </tr>
    </thead>
	<tbody>
<?php
while($fila = $resultado -> fetch_array())
{
?>
		<tr>
            <td><?php echo $fila["puesto_regata"]; ?></td>
            <td><?php echo $fila["modalidad"]; ?></td>			
            <td><?php echo $fila["tiempo_regata"]; ?></td>
            <td><?php echo $fila["lugar"]; ?></td>
            <td><?php echo $fila["fecha"]; ?></td>
			<td><a  title="Actualizar" href="actualizar.php?id=<?php echo $fila["id_historial"];?>"><span class="glyphicon glyphicon-edit"></span></a></td>
		 </tr>
<?php
}
mysqli_close($MySQLi_CON);
}
?>
			  
    </tbody>
</table>



</div>

<script src="../../../bootstrap/js/jquery.js" type="text/javascript"></script>
<script type="text/javascript" src="../../../bootstrap/js/bootstrap.min.js"></script>


</body>
</html>